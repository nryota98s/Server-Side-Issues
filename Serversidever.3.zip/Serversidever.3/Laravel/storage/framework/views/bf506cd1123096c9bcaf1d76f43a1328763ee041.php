<!DOCTYPE html>


<html>


<head>

  <meta charset='utf-8"'>

  <link rel='stylesheet' href='/css/app.css'>

  <meta name="viewport" content="width=device-width, initial-scale=1">

</head>


<body>


  <header>

    <h1 class='page-header'>サーバーサイド課題 沼村竜汰</h1>

  </header>

  <div class='container'>

    <h2 class='page-header'>投稿内容を変更する</h2>
    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
      <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    </div>
    <?php endif; ?>

    <?php echo Form::open(['url' => '/post/update']); ?>


    <div class="form-group">
      <?php echo Form::hidden('id', $post->id); ?>

      <?php echo Form::input('text', 'userName', Auth:: user()->name, ['class' => 'form-control', 'required','placeholder' => 'ユーザーネーム']); ?>


      <?php echo Form::input('text', 'upPost', $post->contents, ['required', 'class' => 'form-control']); ?>




    </div>

    <button type="submit" class="btn btn-primary pull-right">更新</button>

    <?php echo Form::close(); ?>


  </div>

  <footer>



  </footer>

  <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>

  <script src="//cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.1/js/bootstrap.min.js"></script>

</body>


</html>
<?php /**PATH /Applications/MAMP/htdocs/Serverside/Laravel/resources/views/updateForm.blade.php ENDPATH**/ ?>