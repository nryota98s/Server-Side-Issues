<!DOCTYPE html>

<html>


<head>

  <meta charset='utf-8"'>

  <link rel='stylesheet' href='/css/app.css'>

  <meta name="viewport" content="width=device-width, initial-scale=1">

</head>


<body>


  <header>

    <h1 class='page-header'>サーバーサイド課題 沼村竜汰</h1>

  </header>

  <div class='container'>

    <h2 class='page-header'>新しく投稿をする</h2>
    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
      <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    </div>
    <?php endif; ?>


    <?php echo Form::open(['url' => 'post/create']); ?>


    <div class="form-group">

      <?php echo Form::input('text', 'userName', Auth:: user()->name, ['class' => 'form-control', 'required','placeholder' => 'ユーザーネーム']); ?>



      <?php echo Form::input('text', 'newPost', null, ['required', 'class' => 'form-control', 'placeholder' => '投稿内容','value'=>"<?php echo e(old('newPost')); ?>"]); ?>



    </div>

    <button type="submit" class="btn btn-success pull-right">追加</button>

    <?php echo Form::close(); ?>


  </div>


  <footer>


  </footer>

  <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>

  <script src="//cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.1/js/bootstrap.min.js"></script>

</body>


</html>
<?php /**PATH /Applications/MAMP/htdocs/Serverside/Laravel/resources/views/createForm.blade.php ENDPATH**/ ?>