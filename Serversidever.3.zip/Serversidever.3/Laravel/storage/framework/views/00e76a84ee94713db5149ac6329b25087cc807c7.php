<!DOCTYPE html>

<html>


<head>

  <meta charset='utf-8"'>

  <link rel='stylesheet' href="<?php echo e(asset('/css/app.css')); ?>">

  <meta name="viewport" content="width=device-width, initial-scale=1">

</head>


<body>

  <header>

    <h1>サーバーサイド課題 沼村竜汰</h1>
    <div class="dropdown-menu">
      <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
        <?php echo e(Auth:: user()->name); ?>

      </a>
    </div>

    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
      <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
        <?php echo e(__('ログアウト')); ?>

      </a>

      <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
        <?php echo csrf_field(); ?>
      </form>
    </div>
  </header>

  <div class='container'>
    <?php echo Form::open(['url' => '/main']); ?>

    <?php echo Form::input('text', 'keyword','', ['class' => 'form-control','placeholder' => 'キーワードを入力']); ?>

    <?php echo Form::input('submit',"",'検索'); ?>


    <div class="post_btn">

      <p class="pull-right"><a class="btn btn-success" href="/create-form">投稿する</a></p>

    </div>
    <?php if(count($list)===0): ?>
    <p>検索結果は0件です。</p>
    <a href="http://127.0.0.1:8000/main">一覧に戻る
      <?php endif; ?>

      <h2 class='page-header'>投稿一覧</h2>

      <table class='table table-hover'>

        <tr>

          <th>名前</th>

          <th>投稿内容</th>

          <th>投稿日時</th>

          <th></th>
          <th></th>
        </tr>

        <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <tr>

          <td><?php echo e($list->user_name); ?></td>

          <td><?php echo e($list->contents); ?></td>

          <td><?php echo e($list->created_at); ?></td>

          <td><a class="btn btn-primary" href="/post/<?php echo e($list->id); ?>/update-form">更新</a></td>

          <td><a class="btn btn-danger" href="/post/<?php echo e($list->id); ?>/delete" onclick="return confirm('こちらの投稿を削除してもよろしいでしょうか？')">削除</a></td>
        </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      </table>

  </div>


  <footer>



  </footer>

  <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>

</body>


</html>
<?php /**PATH /Applications/MAMP/htdocs/Serverside/Laravel/resources/views/main.blade.php ENDPATH**/ ?>